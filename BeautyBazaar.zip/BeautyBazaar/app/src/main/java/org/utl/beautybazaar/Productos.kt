package org.utl.beautybazaar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Composable
fun ProductsScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFCE4EC))
            .padding(16.dp)
    ) {
        Text(
            "Categorías 💅",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFAD1457)
        )
        Spacer(modifier = Modifier.height(10.dp))

        val categories = listOf(
            "Labiales" to "labiales",
            "Sombras" to "sombras",
            "Bases" to "bases",
            "Brochas" to "brochas",
            "Perfumes" to "perfumes"
        )

        categories.forEach { (name, route) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { navController.navigate(route) },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = name,
                    modifier = Modifier.padding(16.dp),
                    fontSize = 18.sp,
                    color = Color(0xFFD81B60)
                )
            }
        }
    }
}

