package org.utl.beautybazaar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CartScreen(cartViewModel: CartViewModel) {
    val cartItems = cartViewModel.cartItems

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFEBEE))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Tu carrito 🛍️",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFD81B60)
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (cartItems.isEmpty()) {
            Text(
                "Tu carrito está vacío 💅",
                fontSize = 16.sp,
                color = Color.DarkGray
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartItems) { (name, desc, price) ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(name, fontWeight = FontWeight.Bold, color = Color(0xFFD81B60))
                            Text(desc, color = Color.DarkGray)
                            Text("Precio: $${price}", color = Color.Black)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            val total = cartItems.sumOf { it.third }
            Text(
                "Total: $${"%.2f".format(total)}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFD81B60)
            )
        }
    }
}
