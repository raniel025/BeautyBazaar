package org.utl.beautybazaar

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel

class CartViewModel : ViewModel() {
    private val _cartItems = mutableStateListOf<Triple<String, String, Double>>()
    val cartItems: List<Triple<String, String, Double>> = _cartItems

    fun addToCart(item: Triple<String, String, Double>) {
        _cartItems.add(item)
    }

    fun clearCart() {
        _cartItems.clear()
    }
}
