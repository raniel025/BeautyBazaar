package org.utl.beautybazaar

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

@Composable
fun NavigationHost(navController: NavHostController, cartViewModel: CartViewModel) {
    NavHost(navController, startDestination = "home") {
        composable("home") { HomeScreen() }
        composable("products") { ProductsScreen(navController) }
        composable("cart") { CartScreen(cartViewModel) }

        composable("labiales") {
            CategoryScreen(
                "Labiales",
                listOf(
                    Triple("Labial Mate", "Acabado aterciopelado y duradero.", 120.0),
                    Triple("Labial Brillante", "Brillo intenso y color vibrante.", 130.0),
                    Triple("Labial Rojo", "Tono rojo pasión, ideal para noche.", 140.0)
                ),
                R.drawable.labial,
                cartViewModel
            )
        }

        composable("sombras") {
            CategoryScreen(
                "Sombras",
                listOf(
                    Triple("Sombra Nude", "Paleta de tonos suaves y naturales.", 150.0),
                    Triple("Sombra Glitter", "Brillo intenso para looks nocturnos.", 160.0),
                    Triple("Sombra Rosa", "Sombras románticas con acabado satinado.", 155.0)
                ),
                R.drawable.sombra,
                cartViewModel
            )
        }

        composable("bases") {
            CategoryScreen(
                "Bases",
                listOf(
                    Triple("Base Líquida", "Cobertura media con acabado natural.", 220.0),
                    Triple("Base Compacta", "Textura polvo-crema ideal para piel grasa.", 200.0),
                    Triple("Base en Barra", "Alta cobertura con acabado profesional.", 240.0)
                ),
                R.drawable.base,
                cartViewModel
            )
        }

        composable("brochas") {
            CategoryScreen(
                "Brochas",
                listOf(
                    Triple("Brocha Kabuki", "Perfecta para aplicar base líquida o polvo.", 180.0),
                    Triple("Brocha Difuminadora", "Ideal para mezclar sombras.", 160.0),
                    Triple("Brocha Angular", "Perfecta para contorno y rubor.", 170.0)
                ),
                R.drawable.brocha,
                cartViewModel
            )
        }

        composable("perfumes") {
            CategoryScreen(
                "Perfumes",
                listOf(
                    Triple("Perfume Floral", "Aroma fresco con notas de jazmín.", 300.0),
                    Triple("Perfume Dulce", "Toques de vainilla y frutas tropicales.", 320.0),
                    Triple("Perfume Amaderado", "Esencia elegante y sofisticada.", 350.0)
                ),
                R.drawable.perfume,
                cartViewModel
            )
        }
    }
}

@Composable
fun CategoryScreen(
    category: String,
    products: List<Triple<String, String, Double>>,
    imageRes: Int,
    cartViewModel: CartViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFEBEE))
            .padding(16.dp)
    ) {
        Text(
            text = category,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFD81B60),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 60.dp)
        ) {
            items(products) { (name, desc, price) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(id = imageRes),
                            contentDescription = name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .padding(10.dp),
                            contentScale = ContentScale.Crop
                        )
                        Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD81B60))
                        Text(desc, fontSize = 14.sp, color = Color.DarkGray, modifier = Modifier.padding(8.dp))
                        Text("Precio: $${price}", fontSize = 16.sp, color = Color.Black)
                        Button(
                            onClick = { cartViewModel.addToCart(Triple(name, desc, price)) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD81B60)),
                            modifier = Modifier.padding(bottom = 10.dp)
                        ) {
                            Text("Agregar al carrito 🛒", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
